# include <stdio.h>
# include <stdlib.h>

int main(void){
  for(int k = 0 ; k < 10 ; ++k) {
    printf(" % d \n" , k);
  }
  return EXIT_SUCCESS;
}


